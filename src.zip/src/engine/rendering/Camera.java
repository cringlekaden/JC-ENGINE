package engine.rendering;

import engine.components.GameComponent;
import engine.core.InputHandler;
import engine.core.Matrix4f;
import engine.core.Vector2f;
import engine.core.Vector3f;

import static org.lwjgl.glfw.GLFW.*;

public class Camera extends GameComponent {

    private final InputHandler input = InputHandler.getInstance();
    public static final Vector3f yAxis = new Vector3f(0,1,0);

    private final Matrix4f projection;

    public Camera(float fov, float aspect, float zNear, float zFar)
    {
        this.projection = new Matrix4f().initPerspective(fov, aspect, zNear, zFar);
    }

    public Matrix4f getViewProjection()
    {
        Matrix4f cameraRotation = getTransform().getTransformedRotation().conjugate().toRotationMatrix();
        Vector3f cameraPos = getTransform().getTransformedPosition().mul(-1);

        Matrix4f cameraTranslation = new Matrix4f().initTranslation(cameraPos.getX(), cameraPos.getY(), cameraPos.getZ());

        return projection.mul(cameraRotation.mul(cameraTranslation));
    }

    @Override
    public void addToRenderingEngine(RenderingEngine renderingEngine)
    {
        renderingEngine.setMainCamera(this);
    }

    boolean mouseLocked = false;
    Vector2f centerPosition = new Vector2f((float) Window.getWidth() /2, (float) Window.getHeight() /2);

    @Override
    public void input(float delta)
    {
        float sensitivity = 0.5f;
        float movAmt = 10 * delta;
//		float rotAmt = (float)(100 * Time.getDelta());

        if(input.isKeyDown(GLFW_KEY_ESCAPE))
        {
            input.setCursor(true);
            mouseLocked = false;
        }
        if(input.isMouseButtonDown(GLFW_MOUSE_BUTTON_1))
        {
            input.setMousePosition(centerPosition);
            input.setCursor(false);
            mouseLocked = true;
        }

        if(input.isKeyDown(GLFW_KEY_W))
            move(getTransform().getRotation().getForward(), movAmt);
        if(input.isKeyDown(GLFW_KEY_S))
            move(getTransform().getRotation().getForward(), -movAmt);
        if(input.isKeyDown(GLFW_KEY_A))
            move(getTransform().getRotation().getLeft(), movAmt);
        if(input.isKeyDown(GLFW_KEY_D))
            move(getTransform().getRotation().getRight(), movAmt);
        if(mouseLocked)
        {
            Vector2f deltaPos = input.getMousePosition().sub(centerPosition);
            boolean rotY = deltaPos.getX() != 0;
            boolean rotX = deltaPos.getY() != 0;
            if(rotY)
                getTransform().rotate(yAxis, (float) Math.toRadians(deltaPos.getX() * sensitivity));
            if(rotX)
                getTransform().rotate(getTransform().getRotation().getRight(), (float) Math.toRadians(-deltaPos.getY() * sensitivity));
            if(rotY || rotX)
                input.setMousePosition(new Vector2f((float) Window.getWidth() /2, (float) Window.getHeight() /2));
        }
    }

    public void move(Vector3f dir, float amt)
    {
        getTransform().setPosition(getTransform().getPosition().add(dir.mul(amt)));
    }
}