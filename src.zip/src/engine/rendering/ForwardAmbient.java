package engine.rendering;

import engine.core.Transform;
import engine.core.Matrix4f;

public class ForwardAmbient extends Shader {

    private static final ForwardAmbient instance = new ForwardAmbient();

    private ForwardAmbient() {
        super();
        addVertexShaderFromFile("fr-ambient.vs");
        addFragmentShaderFromFile("fr-ambient.fs");
        compileShader();
        addUniform("MVP");
        addUniform("ambientIntensity");
    }

    @Override
    public void updateUniforms(Transform transform, Material material) {
        Matrix4f worldMatrix = transform.getTransformation();
        Matrix4f projectedMatrix = getRenderingEngine().getMainCamera().getViewProjection().mul(worldMatrix);
        material.getTexture().bind();
        setUniform("MVP", projectedMatrix);
        setUniform("ambientIntensity", getRenderingEngine().getAmbientLight());
    }

    public static ForwardAmbient getInstance() {
        return instance;
    }
}
