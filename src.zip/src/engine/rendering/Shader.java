package engine.rendering;

import engine.core.Transform;
import engine.core.Util;
import engine.core.Matrix4f;
import engine.core.Vector3f;
import org.lwjgl.opengl.GL20;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.HashMap;

import static org.lwjgl.opengl.GL20.*;
import static org.lwjgl.opengl.GL32.GL_GEOMETRY_SHADER;

public class Shader {

    private RenderingEngine renderingEngine;
    private final HashMap<String, Integer> uniforms;
    private final int programID;

    public Shader() {
        programID = glCreateProgram();
        uniforms = new HashMap<>();
        if(programID == 0) {
            System.err.println("Shader program creation failed...");
            System.exit(1);
        }
    }

    public void updateUniforms(Transform transform, Material material) {}

    public void addVertexShader(String text) {
        addProgram(text, GL_VERTEX_SHADER);
    }

    public void addFragmentShader(String text) {
        addProgram(text, GL_FRAGMENT_SHADER);
    }

    public void addGeometryShader(String text) {
        addProgram(text, GL_GEOMETRY_SHADER);
    }

    public void addVertexShaderFromFile(String fileName) {
        addProgram(loadShader(fileName), GL_VERTEX_SHADER);
    }

    public void addFragmentShaderFromFile(String fileName) {
        addProgram(loadShader(fileName), GL_FRAGMENT_SHADER);
    }

    public void addGeometryShaderFromFile(String fileName) {
        addProgram(loadShader(fileName), GL_GEOMETRY_SHADER);
    }

    public void compileShader() {
        glLinkProgram(programID);
        if(glGetProgrami(programID, GL_LINK_STATUS) == 0) {
            System.err.println("Shader program link failed...");
            System.err.println(glGetProgramInfoLog(programID, 1024));
            System.exit(1);
        }
        glValidateProgram(programID);
        if(glGetProgrami(programID, GL_VALIDATE_STATUS) == 0) {
            System.err.println("Shader program validate failed...");
            System.err.println(glGetProgramInfoLog(programID, 1024));
            System.exit(1);
        }
    }

    public void bind() {
        glUseProgram(programID);
    }

    public void addUniform(String uniform) {
        int uniformLocation = glGetUniformLocation(programID, uniform);
        if(uniformLocation == 0xFFFFFFFF) {
            System.err.println("Error: Could not find uniform: " + uniform);
            new Exception().printStackTrace();
            System.exit(1);
        }
        uniforms.put(uniform, uniformLocation);
    }

    public void setUniform(String uniform, int value) {
        glUniform1i(uniforms.get(uniform), value);
    }

    public void setUniform(String uniform, float value) {
        glUniform1f(uniforms.get(uniform), value);
    }

    public void setUniform(String uniform, Vector3f vector) {
        glUniform3f(uniforms.get(uniform), vector.getX(), vector.getY(), vector.getZ());
    }

    public void setUniform(String uniform, Matrix4f matrix) {
        GL20.glUniformMatrix4fv(uniforms.get(uniform), false, Util.createFlippedBuffer(matrix));
    }

    public void setRenderingEngine(RenderingEngine renderingEngine) {
        this.renderingEngine = renderingEngine;
    }

    public RenderingEngine getRenderingEngine() {
        return renderingEngine;
    }

    private void addProgram(String text, int type) {
        int shader = glCreateShader(type);
        if(shader == 0) {
            System.err.println("Shader program add failed pre-compilation...");
            System.exit(1);
        }
        glShaderSource(shader, text);
        glCompileShader(shader);
        if(glGetShaderi(shader, GL_COMPILE_STATUS) == 0) {
            System.err.println("Shader compile failed...");
            System.err.println(glGetShaderInfoLog(shader, 1024));
            System.exit(1);
        }
        glAttachShader(programID, shader);
    }

    private static String loadShader(String fileName) {
        StringBuilder shaderSource = new StringBuilder();
        BufferedReader shaderReader;
        try {
            shaderReader = new BufferedReader(new FileReader("./res/shaders/" + fileName));
            String line;
            while((line = shaderReader.readLine()) != null)
                shaderSource.append(line).append("\n");
            shaderReader.close();
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
        return shaderSource.toString();
    }
}
