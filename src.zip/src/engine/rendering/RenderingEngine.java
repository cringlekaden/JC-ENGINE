package engine.rendering;

import engine.components.BaseLight;
import engine.core.GameObject;
import engine.core.Vector3f;

import java.util.ArrayList;

import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.opengl.GL32.GL_DEPTH_CLAMP;

public class RenderingEngine {

    private Camera mainCamera;
    private final Vector3f ambientLight;

    // TODO: MORE "Permanent" structures
    private final ArrayList<BaseLight> lights;
    private BaseLight activeLight;

    public RenderingEngine() {
        glClearColor(0.05f, 0.05f, 0.05f, 1.0f);
        glFrontFace(GL_CW);
        glCullFace(GL_BACK);
        glEnable(GL_CULL_FACE);
        glEnable(GL_DEPTH_TEST);
        glEnable(GL_DEPTH_CLAMP);
        glEnable(GL_TEXTURE_2D);
        ambientLight = new Vector3f(0.1f, 0.1f, 0.1f);
        lights = new ArrayList<>();
    }

    public Vector3f getAmbientLight() {
        return ambientLight;
    }

    public BaseLight getActiveLight() {
        return activeLight;
    }

    public void render(GameObject object) {
        clearScreen();
        lights.clear();
        object.addToRenderingEngine(this);
        Shader forwardAmbient = ForwardAmbient.getInstance();
        forwardAmbient.setRenderingEngine(this);
        object.render(forwardAmbient);
        glEnable(GL_BLEND);
        glBlendFunc(GL_ONE, GL_ONE);
        glDepthMask(false);
        glDepthFunc(GL_EQUAL);
        for(BaseLight light : lights) {
            light.getShader().setRenderingEngine(this);
            activeLight = light;
            object.render(light.getShader());
        }
        glDepthFunc(GL_LESS);
        glDepthMask(true);
        glDisable(GL_BLEND);
    }

    private static void enableTextures(boolean enabled) {
        if(enabled)
            glEnable(GL_TEXTURE_2D);
        else
            glDisable(GL_TEXTURE_2D);
    }

    private static void clearScreen() {
        //TODO: stencil buffer
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    }

    private static void setClearColor(Vector3f color) {
        glClearColor(color.getX(), color.getY(), color.getZ(), 1.0f);
    }

    private static void unbindTextures() {
        glBindTexture(GL_TEXTURE_2D, 0);
    }

    public static String getOpenGLVersion() {
        return glGetString(GL_VERSION);
    }

    public Camera getMainCamera() {
        return mainCamera;
    }

    public void setMainCamera(Camera mainCamera) {
        this.mainCamera = mainCamera;
    }

    public void addLight(BaseLight light) {
        lights.add(light);
    }
}
