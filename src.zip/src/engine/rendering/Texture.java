package engine.rendering;

import de.matthiasmann.twl.utils.PNGDecoder;
import org.lwjgl.opengl.GL11;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.ByteBuffer;

import static org.lwjgl.opengl.GL11.*;

public class Texture {

    private final int textureID;

    public Texture(String fileName) {
        this(loadTexture(fileName));
    }

    public Texture(int textureID) {
        this.textureID = textureID;
    }

    public void bind() {
        glBindTexture(GL_TEXTURE_2D, textureID);
    }

    private static int loadTexture(String fileName) {
        FileInputStream in;
        PNGDecoder decoder;
        try {
            in = new FileInputStream("res/textures/" + fileName + ".png");
        } catch (FileNotFoundException e) {
            System.err.println(fileName + ".png load failed...");
            throw new RuntimeException(e);
        } catch (IOException e) {
            System.err.println(fileName + ".png load failed...");
            throw new RuntimeException(e);
        }
        try {
            decoder = new PNGDecoder(in);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        ByteBuffer buffer = ByteBuffer.allocateDirect(4*decoder.getWidth()*decoder.getHeight());
        try {
            decoder.decode(buffer, decoder.getWidth()*4, PNGDecoder.Format.RGBA);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        buffer.flip();
        int textureID = GL11.glGenTextures();
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, textureID);
        GL11.glTexImage2D(GL11.GL_TEXTURE_2D, 0, GL11.GL_RGBA, decoder.getWidth(), decoder.getHeight(),
                0, GL11.GL_RGBA, GL11.GL_UNSIGNED_BYTE, buffer);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_NEAREST);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_NEAREST);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_S, GL11.GL_REPEAT);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_T, GL11.GL_REPEAT);
        try {
            in.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return textureID;
    }

    public int getID() {
        return textureID;
    }
}
