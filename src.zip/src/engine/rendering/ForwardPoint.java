package engine.rendering;

import engine.components.BaseLight;
import engine.components.PointLight;
import engine.core.Transform;
import engine.core.Matrix4f;

public class ForwardPoint extends Shader {

    private static final ForwardPoint instance = new ForwardPoint();

    private ForwardPoint() {
        super();
        addVertexShaderFromFile("fr-point.vs");
        addFragmentShaderFromFile("fr-point.fs");
        compileShader();
        addUniform("model");
        addUniform("MVP");
        addUniform("cameraPosition");
        addUniform("specularIntensity");
        addUniform("specularExponent");
        addUniform("pointLight.baseLight.color");
        addUniform("pointLight.baseLight.intensity");
        addUniform("pointLight.atten.constant");
        addUniform("pointLight.atten.linear");
        addUniform("pointLight.atten.exponent");
        addUniform("pointLight.position");
        addUniform("pointLight.range");
    }

    @Override
    public void updateUniforms(Transform transform, Material material) {
        Matrix4f worldMatrix = transform.getTransformation();
        Matrix4f projectedMatrix = getRenderingEngine().getMainCamera().getViewProjection().mul(worldMatrix);
        material.getTexture().bind();
        setUniform("model", worldMatrix);
        setUniform("MVP", projectedMatrix);
        setUniform("cameraPosition", getRenderingEngine().getMainCamera().getTransform().getTransformedPosition());
        setUniform("specularIntensity", material.getSpecularIntensity());
        setUniform("specularExponent", material.getSpecularExponent());
        setUniform("pointLight", (PointLight) getRenderingEngine().getActiveLight());
    }

    public void setUniform(String uniform, BaseLight baseLight) {
        setUniform(uniform + ".color", baseLight.getColor());
        setUniform(uniform + ".intensity", baseLight.getIntensity());
    }

    public void setUniform(String uniform, PointLight pointLight) {
        setUniform(uniform + ".baseLight", (BaseLight) pointLight);
        setUniform(uniform + ".atten.constant", pointLight.getAtten().getConstant());
        setUniform(uniform + ".atten.linear", pointLight.getAtten().getLinear());
        setUniform(uniform + ".atten.exponent", pointLight.getAtten().getExponent());
        setUniform(uniform + ".position", pointLight.getTransform().getPosition());
        setUniform(uniform + ".range", pointLight.getRange());
    }

    public static ForwardPoint getInstance() {
        return instance;
    }
}
