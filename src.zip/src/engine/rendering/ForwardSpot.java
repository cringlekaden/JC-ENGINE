package engine.rendering;

import engine.components.BaseLight;
import engine.components.PointLight;
import engine.components.SpotLight;
import engine.core.Transform;
import engine.core.Matrix4f;

public class ForwardSpot extends Shader {

    private static final ForwardSpot instance = new ForwardSpot();

    private ForwardSpot() {
        super();
        addVertexShaderFromFile("fr-spot.vs");
        addFragmentShaderFromFile("fr-spot.fs");
        compileShader();
        addUniform("model");
        addUniform("MVP");
        addUniform("cameraPosition");
        addUniform("specularIntensity");
        addUniform("specularExponent");
        addUniform("spotLight.pointLight.baseLight.color");
        addUniform("spotLight.pointLight.baseLight.intensity");
        addUniform("spotLight.pointLight.atten.constant");
        addUniform("spotLight.pointLight.atten.linear");
        addUniform("spotLight.pointLight.atten.exponent");
        addUniform("spotLight.pointLight.position");
        addUniform("spotLight.pointLight.range");
        addUniform("spotLight.direction");
        addUniform("spotLight.cutoff");
    }

    @Override
    public void updateUniforms(Transform transform, Material material) {
        Matrix4f worldMatrix = transform.getTransformation();
        Matrix4f projectedMatrix = getRenderingEngine().getMainCamera().getViewProjection().mul(worldMatrix);
        material.getTexture().bind();
        setUniform("model", worldMatrix);
        setUniform("MVP", projectedMatrix);
        setUniform("cameraPosition", getRenderingEngine().getMainCamera().getTransform().getTransformedPosition());
        setUniform("specularIntensity", material.getSpecularIntensity());
        setUniform("specularExponent", material.getSpecularExponent());
        setUniform("spotLight", (SpotLight) getRenderingEngine().getActiveLight());
    }

    public void setUniform(String uniform, BaseLight baseLight) {
        setUniform(uniform + ".color", baseLight.getColor());
        setUniform(uniform + ".intensity", baseLight.getIntensity());
    }

    public void setUniform(String uniform, PointLight pointLight) {
        setUniform(uniform + ".baseLight", (BaseLight) pointLight);
        setUniform(uniform + ".atten.constant", pointLight.getAtten().getConstant());
        setUniform(uniform + ".atten.linear", pointLight.getAtten().getLinear());
        setUniform(uniform + ".atten.exponent", pointLight.getAtten().getExponent());
        setUniform(uniform + ".position", pointLight.getTransform().getPosition());
        setUniform(uniform + ".range", pointLight.getRange());
    }

    public void setUniform(String uniform, SpotLight spotLight) {
        setUniform(uniform + ".pointLight", (PointLight) spotLight);
        setUniform(uniform + ".direction", spotLight.getDirection());
        setUniform(uniform + ".cutoff", spotLight.getCutoff());
    }

    public static ForwardSpot getInstance() {
        return instance;
    }
}
