package engine.rendering;

import engine.components.BaseLight;
import engine.components.DirectionalLight;
import engine.core.Transform;
import engine.core.Matrix4f;

public class ForwardDirectional extends Shader {

    private static final ForwardDirectional instance = new ForwardDirectional();

    private ForwardDirectional() {
        super();
        addVertexShaderFromFile("fr-directional.vs");
        addFragmentShaderFromFile("fr-directional.fs");
        compileShader();
        addUniform("model");
        addUniform("MVP");
        addUniform("cameraPosition");
        addUniform("specularIntensity");
        addUniform("specularExponent");
        addUniform("directionalLight.baseLight.color");
        addUniform("directionalLight.baseLight.intensity");
        addUniform("directionalLight.direction");
    }

    @Override
    public void updateUniforms(Transform transform, Material material) {
        Matrix4f worldMatrix = transform.getTransformation();
        Matrix4f projectedMatrix = getRenderingEngine().getMainCamera().getViewProjection().mul(worldMatrix);
        material.getTexture().bind();
        setUniform("model", worldMatrix);
        setUniform("MVP", projectedMatrix);
        setUniform("cameraPosition", getRenderingEngine().getMainCamera().getTransform().getTransformedPosition());
        setUniform("specularIntensity", material.getSpecularIntensity());
        setUniform("specularExponent", material.getSpecularExponent());
        setUniform("directionalLight", (DirectionalLight) getRenderingEngine().getActiveLight());
    }

    public void setUniform(String uniform, BaseLight baseLight) {
        setUniform(uniform + ".color", baseLight.getColor());
        setUniform(uniform + ".intensity", baseLight.getIntensity());
    }

    public void setUniform(String uniform, DirectionalLight directionalLight) {
        setUniform(uniform + ".baseLight", (BaseLight) directionalLight);
        setUniform(uniform + ".direction", directionalLight.getDirection());
    }

    public static ForwardDirectional getInstance() {
        return instance;
    }
}
