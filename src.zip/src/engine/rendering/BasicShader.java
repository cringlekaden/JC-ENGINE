package engine.rendering;

import engine.core.Transform;
import engine.core.Matrix4f;

public class BasicShader extends Shader {

    private static final BasicShader instance = new BasicShader();

    private BasicShader() {
        super();
        addVertexShaderFromFile("basicVertex.vs");
        addFragmentShaderFromFile("basicFragment.fs");
        compileShader();
        addUniform("transform");
        addUniform("color");
    }

    @Override
    public void updateUniforms(Transform transform, Material material) {
        Matrix4f worldMatrix = transform.getTransformation();
        Matrix4f projectedMatrix = getRenderingEngine().getMainCamera().getViewProjection().mul(worldMatrix);
        material.getTexture().bind();
        setUniform("transform", projectedMatrix);
        setUniform("color", material.getColor());
    }

    public static BasicShader getInstance() {
        return instance;
    }
}
