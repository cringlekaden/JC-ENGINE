package engine.components;

import engine.rendering.ForwardDirectional;
import engine.core.Vector3f;

public class DirectionalLight  extends BaseLight {

    public DirectionalLight(Vector3f color, float intensity) {
        super(color, intensity);
        setShader(ForwardDirectional.getInstance());
    }

    public Vector3f getDirection() {
        return getTransform().getTransformedRotation().getForward();
    }
}
