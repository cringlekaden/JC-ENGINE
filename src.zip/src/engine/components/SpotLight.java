package engine.components;

import engine.rendering.Attenuation;
import engine.rendering.ForwardSpot;
import engine.core.Vector3f;

public class SpotLight extends PointLight {

    float cutoff;

    public SpotLight(Vector3f color, float intensity, Attenuation atten, float cutoff) {
        super(color, intensity, atten);
        this.cutoff = cutoff;
        setShader(ForwardSpot.getInstance());
    }

    public Vector3f getDirection() {
        return getTransform().getTransformedRotation().getForward();
    }

    public float getCutoff() {
        return cutoff;
    }

    public void setCutoff(float cutoff) {
        this.cutoff = cutoff;
    }
}
